## ----setup, echo=TRUE, results='markup'---------------------------------------
library(sewloreSpecimenTables)
observations <- synthetic_specimens()
print(observations[1:6, ], row.names = FALSE)

## ----pairs, echo=TRUE, results='markup'---------------------------------------
pairs <- pair_specimen_measurements(observations)
print(pairs[, c("cohort", "specimen_id", "wash_cycle", "axis",
                "before_value", "before_unit", "after_value", "after_unit",
                "delta_mm", "change_percent")], row.names = FALSE, digits = 4)

## ----summaries, echo=TRUE, results='markup'-----------------------------------
summary_table <- summarise_specimen_pairs(pairs)
print(summary_table, row.names = FALSE, digits = 4)

## ----incomplete, echo=TRUE, results='markup'----------------------------------
incomplete_observations <- observations[-2, ]
reported <- pair_specimen_measurements(incomplete_observations, incomplete = "report")
print(reported[reported$status != "paired", ], row.names = FALSE)

