<?php
/** @copyright (c) 2026 Sewlore. @license GNU General Public License version 3 or later */
defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\Module as ModuleServiceProvider;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory as ModuleDispatcherFactoryServiceProvider;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->registerServiceProvider(new ModuleDispatcherFactoryServiceProvider('\\Sewlore\\Module\\MeasurementLab'));
        $container->registerServiceProvider(new ModuleServiceProvider());
    }
};
