<?php
/** @copyright (c) 2026 Sewlore. @license GNU General Public License version 3 or later */
defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_sewlore_measurement_lab');
$wa->useScript('mod_sewlore_measurement_lab.calculator')->useStyle('mod_sewlore_measurement_lab.calculator');
$escape = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$label = static fn (string $key): string => $escape(Text::_('MOD_SEWLORE_MEASUREMENT_LAB_' . $key));
$id = $escape($calculatorId);
?>
<section id="<?php echo $id; ?>" class="sewlore-measurement-lab" data-sewlore-measurement-lab
    data-invalid="<?php echo $label('INVALID'); ?>" data-shrinkage="<?php echo $label('SHRINKAGE_RESULT'); ?>"
    data-print="<?php echo $label('PRINT_RESULT'); ?>" data-conversion="<?php echo $label('CONVERSION_RESULT'); ?>">
  <h3><?php echo $label('TITLE'); ?></h3>
  <p><?php echo $label('INTRO'); ?></p>
  <fieldset>
    <legend><?php echo $label('CONVERSION'); ?></legend>
    <label for="<?php echo $id; ?>-amount"><?php echo $label('VALUE'); ?></label>
    <input id="<?php echo $id; ?>-amount" data-field="amount" type="number" step="any" value="1" inputmode="decimal">
    <label for="<?php echo $id; ?>-from"><?php echo $label('FROM'); ?></label>
    <select id="<?php echo $id; ?>-from" data-field="from"><option value="cm">cm</option><option value="mm">mm</option><option value="in">in</option></select>
    <label for="<?php echo $id; ?>-to"><?php echo $label('TO'); ?></label>
    <select id="<?php echo $id; ?>-to" data-field="to"><option value="mm">mm</option><option value="cm">cm</option><option value="in">in</option></select>
    <output data-result="conversion" aria-live="polite"></output>
  </fieldset>
  <fieldset>
    <legend><?php echo $label('SHRINKAGE'); ?></legend>
    <p><?php echo $label('SHRINKAGE_NOTE'); ?></p>
    <label for="<?php echo $id; ?>-before"><?php echo $label('BEFORE'); ?></label>
    <input id="<?php echo $id; ?>-before" data-field="before" type="number" min="0" step="any" value="100" inputmode="decimal">
    <label for="<?php echo $id; ?>-after"><?php echo $label('AFTER'); ?></label>
    <input id="<?php echo $id; ?>-after" data-field="after" type="number" min="0" step="any" value="95" inputmode="decimal">
    <output data-result="shrinkage" aria-live="polite"></output>
  </fieldset>
  <fieldset>
    <legend><?php echo $label('PRINT'); ?></legend>
    <p><?php echo $label('PRINT_NOTE'); ?></p>
    <label for="<?php echo $id; ?>-expected-width"><?php echo $label('EXPECTED_WIDTH'); ?></label>
    <input id="<?php echo $id; ?>-expected-width" data-field="expected-width" type="number" min="0" step="any" value="100" inputmode="decimal">
    <label for="<?php echo $id; ?>-expected-height"><?php echo $label('EXPECTED_HEIGHT'); ?></label>
    <input id="<?php echo $id; ?>-expected-height" data-field="expected-height" type="number" min="0" step="any" value="50" inputmode="decimal">
    <label for="<?php echo $id; ?>-measured-width"><?php echo $label('MEASURED_WIDTH'); ?></label>
    <input id="<?php echo $id; ?>-measured-width" data-field="measured-width" type="number" min="0" step="any" value="96" inputmode="decimal">
    <label for="<?php echo $id; ?>-measured-height"><?php echo $label('MEASURED_HEIGHT'); ?></label>
    <input id="<?php echo $id; ?>-measured-height" data-field="measured-height" type="number" min="0" step="any" value="52" inputmode="decimal">
    <output data-result="print" aria-live="polite"></output>
  </fieldset>
  <p class="sewlore-measurement-lab__privacy"><?php echo $label('PRIVACY'); ?></p>
  <noscript><p><?php echo $label('NOSCRIPT'); ?></p></noscript>
  <?php if ((int) $params->get('show_credit', 0) === 1) : ?>
    <p class="sewlore-measurement-lab__credit"><a href="https://sewlore.com/"><?php echo $label('CREDIT'); ?></a></p>
  <?php endif; ?>
</section>
