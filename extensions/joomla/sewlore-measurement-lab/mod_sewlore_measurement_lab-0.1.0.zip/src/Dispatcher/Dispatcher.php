<?php
/** @copyright (c) 2026 Sewlore. @license GNU General Public License version 3 or later */
namespace Sewlore\Module\MeasurementLab\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;

final class Dispatcher extends AbstractModuleDispatcher
{
    protected function getLayoutData(): array
    {
        $data = parent::getLayoutData();
        $data['calculatorId'] = 'sewlore-measurement-lab-' . (int) $data['module']->id;

        return $data;
    }
}
