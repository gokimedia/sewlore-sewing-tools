# Pattern Tile Inventory and Assembly Audit

Before taping a PDF sewing pattern, identify the file version, selected size/layer and required page map. A stack with the expected number of sheets can still contain a duplicate and omit a required page.

1. Write the pattern file identity and version on the worksheet.
2. Inventory each required page identifier once.
3. Check orientation and all registration marks using the designer's actual trim/overlap rule.
4. Keep clipping, print-scale questions and line meanings visible as separate checks.
5. Record an unresolved question before making an alteration.

The free four-page A4 and US-Letter worksheet includes a blank inventory, assembly checklist, two fictional digital practice cases and a decision record. The A1/A2/B1/B2 examples and revision labels are invented teaching diagrams. No printer, garment or fabric specimen was tested.

Use the real pattern designer's own instructions for actual printing and assembly. The worksheet does not prescribe a margin width, seam allowance or fitting alteration.

[Sewlore printing and assembly reference](https://sewlore.com/pages/printing-assembly)

Download the PDF from the final public tutorial page. This offline preparation must be hosted and guest-tested before the Sewing4Free form receives a tutorial URL.
